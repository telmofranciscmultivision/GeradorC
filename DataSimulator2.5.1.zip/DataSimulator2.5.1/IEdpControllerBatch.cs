namespace EdpSimulator
{
    public interface IEdpControllerBatch : IEdpController
    {
        // TODO


    }
}